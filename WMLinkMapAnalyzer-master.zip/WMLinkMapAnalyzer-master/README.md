# WMLinkMapAnalyzer
自己写的一个关于xcode linkmap的分析小软件，方便大家跟容易的分析，希望大家多多支持。
使用方法：
第一步，点击选择文件linkmap的路径
第二步，点击开始
第三步，等待一会儿
第四步，可以导出相应的txt文件方便大家分析

![image](show.jpeg)




参考了；https://github.com/Rick630/LinkMap-Analyze (rick630的源代码)
