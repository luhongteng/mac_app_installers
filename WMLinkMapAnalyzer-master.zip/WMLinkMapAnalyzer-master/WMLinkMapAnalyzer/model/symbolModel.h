//
//  symbolModel.h
//  WMLinkMapAnalyzer
//
//  Created by Mac on 16/1/5.
//  Copyright © 2016年 wmeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface symbolModel : NSObject
@property (nonatomic, copy) NSString *file;//文件
@property (nonatomic, assign) NSUInteger size;//大小
@end
